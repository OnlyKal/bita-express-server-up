

from django.urls import path, include

urlpatterns = [
    path('bita/', include('menu.urls')),
]
